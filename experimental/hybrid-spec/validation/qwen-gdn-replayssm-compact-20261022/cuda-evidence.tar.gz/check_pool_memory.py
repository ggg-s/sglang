"""Allocate the production MambaPool tensors without model/server imports.

The model fixture uses the official Qwen3.5-35B-A3B dimensions. Only allocator
integration and the unrelated cache-copy warmup are isolated. This measures the
state pool, not weights, KV, CUDA graphs, or whole-server capacity.
"""

import ast
import dataclasses
import hashlib
import json
import logging
from contextlib import nullcontext
from dataclasses import dataclass, fields
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
path = SOURCE / "python/sglang/srt/mem_cache/memory_pool.py"
tree = ast.parse(path.read_text())
pool = next(
    n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "MambaPool"
)
names = {"__init__", "_detect_conv_window_axis", "_allocate_deduplicated_conv_window"}
pool.body = [
    n
    for n in pool.body
    if isinstance(n, (ast.Assign, ast.AnnAssign))
    or isinstance(n, ast.ClassDef)
    and n.name in {"State", "SpeculativeState"}
    or isinstance(n, ast.FunctionDef)
    and n.name in names
]
definitions = [
    n
    for n in tree.body
    if isinstance(n, ast.FunctionDef)
    and n.name in {"conv_window_dedup_enabled", "get_tensor_size_bytes"}
]
module = ast.Module(
    body=[
        ast.ImportFrom(
            module="__future__", names=[ast.alias(name="annotations")], level=0
        ),
        *definitions,
        pool,
    ],
    type_ignores=[],
)
ast.fix_missing_locations(module)
GB = 1 << 30
_is_npu = _is_cpu = _cpu_has_amx_support = False
envs = SimpleNamespace(SGLANG_DEBUG_MEMORY_POOL=SimpleNamespace(get=lambda: False))
TorchMemorySaverAdapter = SimpleNamespace(
    create=lambda **kw: SimpleNamespace(region=lambda *args: nullcontext())
)
maybe_init_custom_mem_pool = lambda **kw: (False, None, None)
GPU_MEMORY_TYPE_KV_CACHE = "kv_cache"
logger = logging.getLogger(__name__)
namespace = globals() | {
    "dataclasses": dataclasses,
    "dataclass": dataclass,
    "fields": fields,
    "np": np,
}
exec(compile(module, str(path), "exec"), namespace)
MambaPool = namespace["MambaPool"]
get_tensor_size_bytes = namespace["get_tensor_size_bytes"]
MambaPool._warmup_fused_copy_slot_kernel = lambda self: None


def main():
    before = torch.cuda.memory_allocated()
    params = SimpleNamespace(
        shape=SimpleNamespace(
            conv=[(8192, 3)],
            temporal=(32, 128, 128),
            num_k_heads_per_tp=16,
            disable_conv_window_dedup=False,
            conv_kernel=4,
        ),
        dtype=SimpleNamespace(conv=torch.float16, temporal=torch.float32),
        is_kda=False,
    )
    allocated = MambaPool(
        size=40,
        spec_state_size=8,
        cache_params=params,
        mamba_layer_ids=list(range(30)),
        device="cuda",
        speculative_num_draft_tokens=17,
        speculative_eagle_topk=1,
        enable_linear_replayssm_spec=True,
        linear_replayssm_cache_len=64,
    )
    torch.cuda.synchronize()
    cache = allocated.mamba_cache
    assert cache.temporal.dtype == torch.float32
    assert cache.intermediate_ssm is None
    tensors = {
        name: int(get_tensor_size_bytes(getattr(cache, name)))
        for name in (
            "temporal",
            "conv",
            "replayssm_d",
            "replayssm_k",
            "replayssm_g",
            "replayssm_rawv",
            "replayssm_rawk",
        )
    }
    tensors["conv_intermediate_physical"] = int(
        get_tensor_size_bytes(allocated._intermediate_conv_window_phys)
    )
    ring_bytes = sum(
        size for name, size in tensors.items() if name.startswith("replayssm_")
    )
    old_snapshot_bytes = 30 * 9 * 17 * 32 * 128 * 128 * 4
    result = {
        "scope": "production state-pool allocation only; not whole-server memory",
        "config_source": "https://huggingface.co/Qwen/Qwen3.5-35B-A3B-GPTQ-Int4/blob/main/config.json",
        "gpu": torch.cuda.get_device_name(),
        "torch": torch.__version__,
        "ssm_dtype": str(cache.temporal.dtype),
        "conv_dtype": str(cache.conv[0].dtype),
        "pool_size": 40,
        "active_requests": 8,
        "verify_width": 17,
        "ring_length": 64,
        "tensor_bytes": tensors,
        "tensor_total_bytes": sum(tensors.values()),
        "cuda_allocated_delta_bytes": torch.cuda.memory_allocated() - before,
        "replay_ring_bytes": ring_bytes,
        "old_snapshot_bytes_formula": old_snapshot_bytes,
        "snapshot_minus_ring_bytes": old_snapshot_bytes - ring_bytes,
        "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }
    (ROOT / "pool-memory.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
