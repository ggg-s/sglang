#!/bin/bash
set -uo pipefail
out=/workspace/qwen-gdn-replayssm-compact-20261022
runtime=/workspace/conditional-graph-20261019
cd "$out/source" || exit 1
export PATH="$runtime/venv/bin:$runtime/cuda13/bin:$PATH"
export PYTHONPATH=experimental/hybrid-spec/src
export CUDA_HOME="$runtime/cuda13"
export CC=gcc-12 CXX=g++-12 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9
python -m pytest experimental/hybrid-spec/tests/test_gdn_compact.py -q --tb=short --maxfail=4 --junitxml="$out/gdn-replay.xml" > "$out/gdn-replay.log" 2>&1
code=$?
printf '%s\n' "$code" > "$out/gdn-replay.exit"
nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv,noheader > "$out/post-test-gpu.txt"
exit "$code"
