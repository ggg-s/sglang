#!/bin/bash
set -uo pipefail
out=/workspace/qwen-gdn-replayssm-compact-20261022
runtime=/workspace/conditional-graph-20261019
cd "$out/source" || exit 1
export PATH="$runtime/venv/bin:$runtime/cuda13/bin:$PATH"
export PYTHONPATH="$out:experimental/hybrid-spec/src"
export CUDA_HOME="$runtime/cuda13"
export CC=gcc-12 CXX=g++-12 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9
python -m pytest -p lean_cuda_plugin -p capture_gc_plugin experimental/hybrid-spec/tests/test_gdn_compact.py experimental/hybrid-spec/tests/test_compact_verify.py experimental/hybrid-spec/tests/test_compact_tail.py --deselect='experimental/hybrid-spec/tests/test_compact_verify.py::test_draft_extend_graph_state_survives_prefill_merge_and_filter[1-True]' --deselect='experimental/hybrid-spec/tests/test_compact_verify.py::test_draft_extend_graph_state_survives_prefill_merge_and_filter[3-True]'  -q --tb=short --maxfail=4 --junitxml="$out/compact-regression.xml" > "$out/compact-regression.log" 2>&1
code=$?
printf '%s\n' "$code" > "$out/compact-regression.exit"
nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv,noheader > "$out/post-test-gpu.txt"
exit "$code"
