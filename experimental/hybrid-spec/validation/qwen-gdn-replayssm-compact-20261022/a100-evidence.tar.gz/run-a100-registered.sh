#!/bin/bash
set -uo pipefail
source /root/rivermind-data/activate-sglang.sh
out=/root/rivermind-data/validation/qwen-gdn-replayssm-compact-20261022
cd "$out/source"
export PYTHONPATH="$out/source/python:$out/source/experimental/hybrid-spec/src"
export SGLANG_MAMBA_CONV_DTYPE=float16
unset HYBRID_SPEC_CONFIG SGLANG_RAGGED_VERIFY_MODE SGLANG_MAMBA_SSM_DTYPE
python -m pytest test/registered/unit/server_args/test_server_args.py::TestGdnReplayssmCompactArgs test/registered/unit/mem_cache/test_replayssm_ring_accounting.py test/registered/kernels/ops/attention/test_gdn_replayssm_compact.py -q --tb=short --maxfail=3 --junitxml="$out/a100-registered.xml" > "$out/a100-registered.log" 2>&1
code=$?
printf "%s\n" "$code" > "$out/a100-registered.exit"
exit "$code"
