#!/bin/bash
set -uo pipefail
source /root/rivermind-data/activate-sglang.sh
out=/root/rivermind-data/validation/qwen-gdn-replayssm-compact-20261022
cd "$out"
export PYTHONPATH="$out/source/python:$out/source/experimental/hybrid-spec/src"
unset HYBRID_SPEC_CONFIG SGLANG_RAGGED_VERIFY_MODE SGLANG_MAMBA_SSM_DTYPE
nvidia-smi --query-gpu=timestamp,name,utilization.gpu,memory.used,power.draw,clocks.sm,temperature.gpu --format=csv -l 1 > "$out/gpu-telemetry.csv" &
monitor=$!
printf "%s\n" "$monitor" > "$out/telemetry.pid"
python "$out/run_matrix.py" > "$out/matrix.log" 2>&1
code=$?
printf "%s\n" "$code" > "$out/matrix.exit"
kill "$monitor" 2>/dev/null || true
wait "$monitor" 2>/dev/null || true
nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv,noheader > "$out/post-a100-gpu.txt"
exit "$code"
