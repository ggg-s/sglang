#!/bin/sh
runtime=/workspace/conditional-graph-20261019
source_root=/workspace/sa-compact-20261021/source/experimental/hybrid-spec
out=/workspace/sa-phase-20261021
export PATH="$runtime/venv/bin:$runtime/cuda13/bin:$PATH"
export PYTHONPATH="$source_root/src:$source_root/benchmarks"
export CUDA_HOME="$runtime/cuda13"
export CC=gcc-12 CXX=g++-12 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9
python "$out/benchmark_sa_phases_cuda.py" --source "$source_root/src/hybrid_spec/backends/gpu_sa" --output "$out/profile-smoke" --jit-output "$out/smoke" --smoke --profile --rounds 1 --samples 5 > "$out/profile-smoke.log" 2>&1
printf '%s\n' "$?" > "$out/profile-smoke.exit"
