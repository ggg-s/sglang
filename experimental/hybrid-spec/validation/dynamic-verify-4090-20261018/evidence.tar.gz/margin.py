import importlib.util,json,pathlib,time
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
root=pathlib.Path('/root/rivermind-data/benchmarks/dynamic-verify-4090-20261018')
while not (root/'validation.done').exists() or not (root/'gpu-released.done').exists():time.sleep(2)
spec=importlib.util.spec_from_file_location('run',root/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
a=json.loads((root/'native/c4-wave0.json').read_text())['responses'][1]
b=json.loads((root/'fixed/c4-wave0.json').read_text())['responses'][1]
aa=[p[1] for p in a['meta_info']['output_token_logprobs']];bb=[p[1] for p in b['meta_info']['output_token_logprobs']]
pos=next(i for i,(x,y) in enumerate(zip(aa,bb)) if x!=y)
tok=AutoTokenizer.from_pretrained(r.MODEL)
prompt=tok.encode(r.prompts[1]);assert len(prompt)==a['meta_info']['prompt_tokens'],(len(prompt),a['meta_info']['prompt_tokens'])
model=AutoModelForCausalLM.from_pretrained(r.MODEL,torch_dtype=torch.float32,attn_implementation='eager').eval().to('cuda')
with torch.inference_mode():
 logits=model(torch.tensor([prompt+aa[:pos]],device='cuda'),use_cache=False).logits[0,-1].float();values,ids=logits.topk(5)
result=dict(scope='Independent Transformers FP32 eager full-prefill reference at the shared first-divergence prefix; does not establish FP16 path equivalence.',first_difference=pos,native_token=aa[pos],compact_token=bb[pos],top5=[dict(token=int(i),text=tok.decode([i]),logit=float(v)) for i,v in zip(ids,values)],top2_margin=float(values[0]-values[1]),torch=str(torch.__version__))
(root/'divergence-reference.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
