import importlib.util,json,pathlib,traceback
import psutil
root=pathlib.Path('/root/rivermind-data/benchmarks/dynamic-verify-4090-20261018')
spec=importlib.util.spec_from_file_location('run',root/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=None
try:
 cfg=json.loads((root/'fixed/config.json').read_text());p,folder=r.launch('fixed-top5',cfg)
 for c in (1,4):
  body=r.payload(range(c),[128]*c);body['top_logprobs_num']=5
  out=r.api(r.URL,'/generate',body);out=[out] if isinstance(out,dict) else out
  r.save(folder/f'c{c}-top5.json',out)
 x=out[1]['meta_info'];print(json.dumps({k:v[:5] if isinstance(v,list) else v for k,v in x.items() if 'logprob' in k},indent=2),flush=True)
 r.save(folder/'final-info.json',r.api(r.URL,'/get_server_info'))
 (root/'probe.done').write_text('ok\n')
except BaseException:
 print(traceback.format_exc(),flush=True);raise
finally:
 if p is not None:
  try:r.stop(psutil.Process(p.pid))
  except psutil.NoSuchProcess:pass
