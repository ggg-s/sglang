import importlib.util,json,time,traceback
import psutil,requests
from pathlib import Path
root=Path('/root/rivermind-data/benchmarks/dynamic-verify-4090-20261018')
spec=importlib.util.spec_from_file_location('run',root/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
current=None
try:
 cfg=dict(num_drafts=8,num_neural_drafts=3,min_match_len=2,max_requests=16,max_history_tokens=2048,backend='gpu_sa',history_mode='device',partial_drafts='fallback',draft_graph_mode='split',num_neural_gate_tokens=1,verify_mode='compact',enable_global_pool=True,max_shared_requests=16)
 for case,config in [('fixed',cfg),('dynamic',dict(cfg,dynamic_verify=True)),('gate3-neural2',dict(cfg,num_neural_drafts=2,num_neural_gate_tokens=3,dynamic_verify=True,dynamic_verify_min_samples=8,dynamic_verify_explore_interval=8)),('gate8-neural1',dict(cfg,num_neural_drafts=1,num_neural_gate_tokens=8,dynamic_verify=True,dynamic_verify_min_samples=8,dynamic_verify_explore_interval=8))]:
  p,folder=r.launch(case,config);current=psutil.Process(p.pid)
  r.exercise(folder);r.stop(current);current=None
 (root/'validation.done').write_text('ok\n')
 print('VALIDATED',flush=True)
except BaseException as e:
 r.save(root/'failure.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
finally:
 if current is not None:r.stop(current)
 (root/'gpu-released.done').write_text('ok\n')
