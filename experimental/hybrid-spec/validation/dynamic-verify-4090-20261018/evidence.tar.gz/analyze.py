import hashlib,json,pathlib,platform,subprocess
import torch,triton
root=pathlib.Path('/root/rivermind-data/benchmarks/dynamic-verify-4090-20261018')
repo=root/'repo';cases=['native','fixed','dynamic','gate3-neural2','gate8-neural1']
expected=json.loads((root/'source-hashes-v8.json').read_text());assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in expected.items())
rows=[];comparisons=[]
def load(case,file):return json.loads((root/case/file).read_text())
def ids(x):return [p[1] for p in x['meta_info']['output_token_logprobs']]
for case in cases:
 info=load(case,'final-info.json');state=info['internal_states'][0];dyn=state.get('hybrid_spec_dynamic_verify',{})
 runs=load(case,'runs.json')
 row=dict(case=case,completed=sum(x['completed'] for x in runs),output_tokens=sum(x['output_tokens'] for x in runs),hybrid=state.get('hybrid_spec'),split=state.get('hybrid_spec_split_graph'),compact=state.get('hybrid_spec_compact_verify'),dynamic={k:v for k,v in dyn.items() if k not in ['check_ct','correct_ct']},check_ct=sum(map(sum,dyn.get('check_ct',[]))),correct_ct=sum(map(sum,dyn.get('correct_ct',[]))))
 rows.append(row)
 if case!='native':
  for baseline in ['native']+(['fixed'] if case=='dynamic' else []):
   compared=identical=0;diff=[]
   for run in runs:
    f=f'c{run["c"]}-wave{run["wave"]}.json';before=load(baseline,f)['responses'];after=load(case,f)['responses']
    for i,(a,b) in enumerate(zip(before,after)):
     aa,bb=ids(a),ids(b);assert len(aa)==a['meta_info']['completion_tokens'] and len(bb)==b['meta_info']['completion_tokens']
     compared+=1;identical+=aa==bb
     if aa!=bb:diff.append(dict(c=run['c'],wave=run['wave'],row=i,first_difference=next(j for j,(x,y) in enumerate(zip(aa,bb)) if x!=y)))
   comparisons.append(dict(case=case,baseline=baseline,compared=compared,identical=identical,differences=diff))
assert (root/'validation.done').exists()
summary=dict(base_commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),python=platform.python_version(),torch=str(torch.__version__),cuda=torch.version.cuda,triton=triton.__version__,gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,memory.used,driver_version','--format=csv,noheader'],text=True).strip(),source_sha256=expected,rows=rows,output_token_comparisons=comparisons,scope=['Real Qwen3-0.6B weights for both target and standalone draft, FP16, TP1, Triton attention; not DSV4/MTP or EAGLE3 end-to-end.','Five cases, concurrency 1/4/16; three c16 waves with per-request output lengths 96/128/160/192.','Native and fixed compact controls, dynamic default configuration, gate3/neural2 and gate8/neural1; the two boundary cases lower cold/explore intervals to8.','Generation requested output logprobs for token-id comparison; correctness smoke, no serving-performance claim.','Qwen3.6 target and MTP model files removed on explicit user request; old service restoration cancelled.','Failed initial startup exposed missing inherited draft graph mode; corrected in final source and covered by four CPU capture-loop regressions.'])
(root/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['source_sha256','rows']},indent=2))
for r in rows:print(json.dumps(r))
