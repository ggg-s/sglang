"""Warm-cache component probe: same v6 exact-frequency algorithm, two layouts."""
import json
import sys
from pathlib import Path

root = Path('/workspace/sa-compact-20261021')
sys.path.insert(0, str(root / 'source/experimental/hybrid-spec/benchmarks'))
from benchmark_sa_history_cuda import measure
from hybrid_spec.backends.gpu_sa import GPUSuffixAutomaton

module = GPUSuffixAutomaton.load_module()
report = {'scope': __doc__, 'policy': 'frequency', 'repeats': 30,
          'notes': ['Restores GPU state outside events; no model/TP/H2D/feedback-producer timing.',
                    'At capacity 32768 both arms are wide, serving as a noise control.'],
          'results': []}
shapes = [(16384, vocab, 4) for _ in range(3) for vocab in (1, 2)]
for i, (capacity, vocab, bs) in enumerate(shapes):
    row = {'capacity': capacity, 'vocab': vocab, 'batch_size': bs}
    order = ('wide', 'auto') if i % 2 == 0 else ('auto', 'wide')
    for name in order:
        row[name] = measure(module, 10, 1, 6, 7, capacity - 18, vocab, bs, 30,
                            compact_states=name == 'auto', frequency=True)
    assert row['auto']['semantic_checksum'] == row['wide']['semantic_checksum']
    row['auto_over_wide_time'] = row['auto']['median_us'] / row['wide']['median_us']
    row['saved_index_bytes'] = row['wide']['index_bytes'] - row['auto']['index_bytes']
    report['results'].append(row)
    (root / 'layout-repeat-costs.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: row[k] for k in ('capacity', 'vocab', 'batch_size', 'auto_over_wide_time', 'saved_index_bytes')}), flush=True)
