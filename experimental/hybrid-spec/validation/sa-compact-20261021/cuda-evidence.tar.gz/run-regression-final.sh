#!/bin/sh
out=/workspace/sa-compact-20261021
runtime=/workspace/conditional-graph-20261019
cd "$out/source" || exit 1
export PATH="$runtime/venv/bin:$runtime/cuda13/bin:$PATH"
export PYTHONPATH="$out:experimental/hybrid-spec/src"
export CUDA_HOME="$runtime/cuda13"
export CC=gcc-12 CXX=g++-12 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9
python -m pytest -p lean_cuda_plugin -p capture_gc_plugin experimental/hybrid-spec/tests -q --tb=short --maxfail=10 --deselect='tests/test_compact_verify.py::test_draft_extend_graph_state_survives_prefill_merge_and_filter[1-True]' --deselect='tests/test_compact_verify.py::test_draft_extend_graph_state_survives_prefill_merge_and_filter[3-True]' --deselect='tests/test_conditional_verify.py::test_cuda_target_dispatch_runs_only_selected_physical_tier'  --junitxml="$out/regression-final.xml" > "$out/regression-final.log" 2>&1
printf '%s\n' "$?" > "$out/regression-final.exit"
nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv,noheader > "$out/post-test-gpu.txt"
