#!/bin/sh
out=/workspace/sa-compact-20261021
runtime=/workspace/conditional-graph-20261019
cd "$out/source" || exit 1
export PATH="$runtime/venv/bin:$runtime/cuda13/bin:$PATH"
export PYTHONPATH="$out:experimental/hybrid-spec/src"
export CUDA_HOME="$runtime/cuda13"
export CC=gcc-12 CXX=g++-12 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9
python -m pytest experimental/hybrid-spec/tests/test_frequency.py experimental/hybrid-spec/tests/test_native.py experimental/hybrid-spec/tests/test_shared_parallel_cuda.py -q --tb=short --junitxml="$out/frequency-compile.xml" > "$out/frequency-compile.log" 2>&1
printf '%s\n' "$?" > "$out/frequency-compile.exit"
nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv,noheader > "$out/post-test-gpu.txt"
