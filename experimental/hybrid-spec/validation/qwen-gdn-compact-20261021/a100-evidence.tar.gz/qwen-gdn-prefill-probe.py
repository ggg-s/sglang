import json,pathlib,urllib.request
p=pathlib.Path('/root/rivermind-data/validation/qwen-gdn-compact-20261021')
text=json.loads((p/'padded-first-requests.json').read_text())[0]['rows'][6]['prompt']
def req(path,body):
 r=urllib.request.Request('http://127.0.0.1:39921'+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(r,timeout=90) as f:
  s=f.read()
  try:return json.loads(s)
  except:return s.decode()
a=[]
for i in range(10):
 req('/flush_cache',{})
 x=req('/v1/chat/completions',dict(model='default',messages=[dict(role='user',content=text)],temperature=0,max_tokens=1,logprobs=True,top_logprobs=5,chat_template_kwargs={'enable_thinking':False},return_output_ids_in_sglext=True,return_spec_tokens_details=True))
 a.append(x)
 print(i,x['sglext'],x['choices'][0].get('logprobs'),flush=True)
(p/'padded-prefill-probe.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
