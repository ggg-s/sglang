import concurrent.futures,json,pathlib,sys,time,urllib.request
out=pathlib.Path('/root/rivermind-data/validation/qwen-gdn-compact-20261021')
mode=sys.argv[1]
base='http://127.0.0.1:39921'
def http(path,body=None):
 data=None if body is None else json.dumps(body).encode()
 req=urllib.request.Request(base+path,data=data,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=180) as r:
  raw=r.read()
  try: return json.loads(raw or 'null')
  except json.JSONDecodeError: return raw.decode()
def run(case):
 i,text=case
 payload=dict(model='default',messages=[dict(role='user',content=text)],temperature=0,max_tokens=192,stream=False,chat_template_kwargs={'enable_thinking':False},return_output_ids_in_sglext=True,return_spec_tokens_details=True)
 start=time.perf_counter(); result=http('/v1/chat/completions',payload)
 return dict(index=i,prompt=text,wall_s=time.perf_counter()-start,response=result)
prompts=[
 'Write a Python function to merge two sorted lists. Include a short example.',
 '解释二分查找的边界条件，并写出 Python 实现。',
 'Continue this repeating sequence for 40 more items, without explanation: alpha beta gamma alpha beta gamma alpha beta gamma',
 'Write a TypeScript function that removes duplicate strings while preserving their order.',
 'Compute the sum of integers from 1 through 100. Explain the arithmetic briefly.',
 '把这段话改得简洁：这个系统能够通过利用缓存的方式，从而有效地减少重复计算所带来的开销。',
 'Complete the pattern with exactly 20 more rows:\nred green blue\nred green blue\nred green blue\n',
 'Return the following text unchanged, repeated six times:\nThe quick brown fox jumps over the lazy dog.\n',
 'The following is a repeating log. Continue it for 16 lines:\n'+('alpha beta gamma delta epsilon zeta eta theta\n'*480),
 'Write a SQL query to find customers with at least three orders in the last month.',
 'List five edge cases for testing an empty queue implementation.',
 '用三句话说明为什么投机解码要验证草稿。',
]
# Diagnostics occur outside each timed workload. Flush between concurrency groups
# so both modes see the same cache protocol; repeat within each group to exercise
# radix cache reuse, state tracking and request-slot reuse.
records=[]
for concurrency in (1,4):
 http('/flush_cache',{})
 before=http('/get_server_info')
 start=time.perf_counter()
 with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
  rows=list(pool.map(run,enumerate(prompts)))
 elapsed=time.perf_counter()-start
 after=http('/get_server_info')
 records.append(dict(concurrency=concurrency,wall_s=elapsed,before=before,after=after,rows=rows))
 (out/(mode+'-requests.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2))
 print(json.dumps(dict(mode=mode,concurrency=concurrency,requests=len(rows),wall_s=elapsed,tokens=sum(r['response']['usage']['completion_tokens'] for r in rows))),flush=True)
