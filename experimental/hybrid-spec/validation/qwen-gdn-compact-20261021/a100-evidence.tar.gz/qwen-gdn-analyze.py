import json,pathlib,hashlib,collections,statistics
p=pathlib.Path('/root/rivermind-data/validation/qwen-gdn-compact-20261021')
def load(n):return json.loads((p/n).read_text())
def ids(r):return r['response']['sglext']['output_ids'][0]
def metrics(g,when,key):return g[when]['internal_states'][0].get(key,{})
def delta(g,key):
 a,b=metrics(g,'before',key),metrics(g,'after',key)
 return {k:v-a.get(k,0) for k,v in b.items() if isinstance(v,(int,float))}
def compare(a,b):
 rows=[]
 for x,y in zip(a['rows'],b['rows']):
  u,v=ids(x),ids(y)
  rows.append(dict(index=x['index'],exact=u==v,first_difference=next((i for i,(s,t) in enumerate(zip(u,v)) if s!=t),min(len(u),len(v))),tokens_a=len(u),tokens_b=len(v)))
 return dict(concurrency=a['concurrency'],exact=sum(r['exact'] for r in rows),requests=len(rows),rows=rows)
s={'runs':[],'comparisons':{}}
for name in ['compact-first-requests.json','padded-first-requests.json','padded-requests.json','compact-requests.json']:
 for g in load(name):
  d=delta(g,'hybrid_spec_compact_verify'); m=delta(g,'hybrid_spec')
  specs=[r['response']['sglext'].get('spec_tokens_details',{}) for r in g['rows']]
  ct=sum(x.get('spec_verify_ct',0) for x in specs)
  accepted=sum(x.get('spec_num_correct_drafts',0)+x.get('spec_verify_ct',0) for x in specs)
  s['runs'].append(dict(file=name,concurrency=g['concurrency'],requests=len(g['rows']),wall_s=g['wall_s'],output_tokens=sum(len(ids(r)) for r in g['rows']),verify=d,source=m,target_position_reduction=1-d['target_token_ct']/d['dense_token_ct'],accept_length=accepted/ct))
for label,an,bn in [('pair_first','compact-first-requests.json','padded-first-requests.json'),('pair_repeat','compact-requests.json','padded-requests.json'),('padded_self','padded-first-requests.json','padded-requests.json'),('compact_self','compact-first-requests.json','compact-requests.json')]:
 s['comparisons'][label]=[compare(a,b) for a,b in zip(load(an),load(bn))]
probe=load('padded-prefill-probe.json'); s['prefill_only']={'samples':len(probe),'first_tokens':dict(collections.Counter(x['choices'][0]['logprobs']['content'][0]['token'] for x in probe)),'spec_details_present':any('spec_tokens_details' in x.get('sglext',{}) for x in probe)}
cache=load('compact-cache-probe.json'); s['cache_reuse']={'exact':cache[0]['sglext']['output_ids']==cache[1]['sglext']['output_ids'],'prompt_tokens':cache[0]['usage']['prompt_tokens'],'output_tokens':cache[0]['usage']['completion_tokens'],'second_cached_tokens':cache[1]['sglext']['cached_tokens_details']}
(p/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
for r in s['runs']: print(r)
print('comparisons',{k:[x['exact'] for x in v] for k,v in s['comparisons'].items()})
print('prefill',s['prefill_only'],'cache',s['cache_reuse'])
