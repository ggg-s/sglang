#!/usr/bin/env bash
set -euo pipefail
source /root/rivermind-data/activate-sglang.sh
out=/root/rivermind-data/validation/qwen-gdn-compact-20261021
cd "$out/source"
export PYTHONPATH="$out/source/python:$out/source/experimental/hybrid-spec/src"
export SGLANG_PLUGINS=hybrid_spec
export HYBRID_SPEC_CONFIG="$out/${1:-compact}.json"
export SGLANG_MAMBA_CONV_DTYPE=float16
exec python -m sglang.launch_server \
 --model-path /root/rivermind-data/models/Qwen/Qwen3.5-35B-A3B-GPTQ-Int4 \
 --language-only --quantization gptq_marlin --dtype float16 \
 --speculative-algorithm EAGLE --speculative-num-steps 8 \
 --speculative-eagle-topk 1 --speculative-num-draft-tokens 9 \
 --speculative-draft-model-path /root/rivermind-data/validation/split-graph-20261016/mtp-unquant-view \
 --speculative-draft-model-quantization unquant --speculative-moe-runner-backend triton \
 --linear-attn-backend triton --attention-backend triton \
 --speculative-draft-attention-backend triton \
 --tp-size 1 --context-length 8192 --max-running-requests 4 \
 --max-mamba-cache-size 20 --mem-fraction-static 0.8 --random-seed 42 \
 --watchdog-timeout 1800 --cuda-graph-max-bs-decode 4 \
 --cuda-graph-backend-decode full --cuda-graph-backend-prefill disabled \
 --host 127.0.0.1 --port 39921
