import json,pathlib,urllib.request
p=pathlib.Path('/root/rivermind-data/validation/qwen-gdn-compact-20261021')
text=json.loads((p/'compact-requests.json').read_text())[0]['rows'][8]['prompt']
def req(path,body):
 r=urllib.request.Request('http://127.0.0.1:39921'+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(r,timeout=180) as f:
  s=f.read()
  try:return json.loads(s)
  except:return s.decode()
req('/flush_cache',{})
a=[]
for i in range(2):
 r=req('/v1/chat/completions',dict(model='default',messages=[dict(role='user',content=text)],temperature=0,max_tokens=192,chat_template_kwargs={'enable_thinking':False},return_output_ids_in_sglext=True,return_spec_tokens_details=True,return_cached_tokens_details=True))
 a.append(r)
 print(i,r['usage'],{k:v for k,v in r.get('sglext',{}).items() if k!='output_ids'},flush=True)
(p/'compact-cache-probe.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
