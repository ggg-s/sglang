#!/bin/sh
out=/workspace/sa-frequency-20261021
runtime=/workspace/conditional-graph-20261019
cd "$out/source" || exit 1
export PATH="$runtime/venv/bin:$runtime/cuda13/bin:$PATH"
export PYTHONPATH="$out:experimental/hybrid-spec/src"
export CUDA_HOME="$runtime/cuda13"
export CC=gcc-12 CXX=g++-12 MAX_JOBS=2 TORCH_CUDA_ARCH_LIST=8.9
python -m pytest -p lean_cuda_plugin -p capture_gc_plugin experimental/hybrid-spec/tests -q --tb=short --maxfail=12 --junitxml="$out/regression.xml" > "$out/regression.log" 2>&1
printf '%s\n' "$?" > "$out/regression.exit"
nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv,noheader > "$out/post-test-gpu.txt"
